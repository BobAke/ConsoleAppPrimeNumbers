﻿using ConsoleAppPrime.PrimeGen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppPrime
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("\n\n");
            Console.Write("Find the prime numbers within a range of numbers:\n");
            Console.Write("---------------------------------------------------");
            Console.Write("\n\n");

            Console.Write("Input starting number of range: ");
            int stno = Convert.ToInt32(Console.ReadLine());
            Console.Write("Input ending number of range : ");
            int enno = Convert.ToInt32(Console.ReadLine());
            Console.Write("The prime numbers between {0} and {1} are : \n", stno, enno);

            IPrimeNumGenerator primeGen = new PrimeNumGenerator();
            var primeResults = primeGen.PrimeGenerator(stno, enno);
            foreach (var prime in primeResults)
            {
                Console.Write("{0} ", prime);
            }
            Console.Write("\n");
            Console.ReadLine();
            //---------------------------------------------------------------------------------------------------------------------------------------
            //checking if number is prime Num

            Console.Write("\n\n");
            Console.Write("Check if number is Prime numbers:\n");
            Console.Write("---------------------------------------------------");
            Console.Write("\n\n");
            Console.Write("Input starting number of range: ");
            int number = Convert.ToInt32(Console.ReadLine());
            var isPrime = primeGen.isPrimeNumber(number);
            if (isPrime)
            {
                Console.Write("{0} is a Prime number", number);
                Console.Write("\n");
                Console.ReadLine();
            }
            else
            {
                Console.Write("{0} is NOT a Prime number", number);
                Console.Write("\n");
                Console.ReadLine();
            }

        }
    }
}
