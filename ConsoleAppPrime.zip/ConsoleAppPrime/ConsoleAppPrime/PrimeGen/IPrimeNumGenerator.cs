﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppPrime.PrimeGen
{
    public interface IPrimeNumGenerator
    {
        List<int> PrimeGenerator(int startNum, int endNum);
        bool isPrimeNumber(int number);
    }
}
