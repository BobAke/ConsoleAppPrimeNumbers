﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppPrime.PrimeGen
{
    public class PrimeNumGenerator : IPrimeNumGenerator
    {
        public bool isPrimeNumber(int number)
        {
            if (number == 1) return false;
            if (number == 2) return true;
            if (number == 0) return false;

            for (int i = 2; i <= Math.Ceiling(Math.Sqrt(number)); ++i)
            {
                if (number % i == 0) return false;
            }

            return true;
        }

        public List<int> PrimeGenerator(int startNum, int endNum)
        {
            int ctr = 0;
            List<int> primeList = new List<int>();

            if (endNum > startNum)
            {
                for (int num = startNum; num <= endNum; num++)
                {
                    ctr = 0;

                    for (int i = 2; i <= num / 2; i++)
                    {
                        if (num % i == 0)
                        {
                            ctr++;
                            break;
                        }
                    }

                    if (ctr == 0 && num != 1)
                        primeList.Add(num);
                }
            }
            else
            {
                for (int num = startNum; num >= endNum; num--)
                {
                    ctr = 0;

                    for (int i = 2; i <= num / 2; i++)
                    {
                        if (num % i == 0)
                        {
                            ctr++;
                            break;
                        }
                    }

                    if (ctr == 0 && num != 1)
                        primeList.Add(num);
                }
            }
            return primeList;
        }
    }
}
