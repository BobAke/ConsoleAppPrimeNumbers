﻿using System;
using ConsoleAppPrime.PrimeGen;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestPrimenumbers
{
    [TestClass]
    public class PrimeNumersUnitTest
    {
        private IPrimeNumGenerator _primeGen;
        public PrimeNumersUnitTest()
        {
            _primeGen = new PrimeNumGenerator();
        }
        [TestMethod]
        public void TestGeneratePrimeNumber()
        {
            //arrange
            int startNum = 1;
            int endNumber = 200;
            //act
            var actualResult = _primeGen.PrimeGenerator(startNum, endNumber);
            //assert
            Assert.IsTrue(actualResult.Count > 0);

        }

        [TestMethod]
        public void TestIsPrimeNumber()
        {
            //arrange
            int num = 3;

            //act
            var actualResult = _primeGen.isPrimeNumber(num);
            //assert
            Assert.IsTrue(actualResult);

        }

        [TestMethod]
        public void TestIsNotPrimeNumber()
        {
            //arrange
            int num = 6;

            //act
            var actualResult = _primeGen.isPrimeNumber(num);
            //assert
            Assert.IsFalse(actualResult);

        }
    }
}
